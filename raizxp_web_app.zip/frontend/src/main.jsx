
import React from 'react'
import ReactDOM from 'react-dom/client'

function App() {
  return (
    <div className="p-4 font-sans text-center">
      <h1 className="text-2xl font-bold text-green-600">RaízXP App</h1>
      <p className="mt-4">Tu camino, tu juego, tus reglas.</p>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
